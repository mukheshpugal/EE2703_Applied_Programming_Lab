from sympy import *
import scipy.signal as sp
import pylab as pp

def lowpass(R1, R2, C1, C2, G, Vi):
	s = symbols('s')
	A = Matrix([[0, 0, 1, -1 / G], [-1 / (1 + s * R2 * C2), 1, 0, 0], [0, -G, G, 1], [-1 / R1 - 1 / R2 - s * C1, 1 / R2, 0, s * C2]])
	b = Matrix([0, 0, 0, -Vi / R1])
	V = A.inv() * b
	return V[3]

def highpass(R1, R2, C1, C2, G, Vi):
	s = symbols("s")
	A = Matrix([[0, -1, 0, 1 / G], [s * C2 * R2 / (s * C2 * R2 + 1), 0, -1, 0], [0, G, -G, 1], [-s * C2 - 1 / R1 - s * C1, 0, s * C2, 1 / R1]])
	b = Matrix([0, 0, 0, -Vi * s * C1])
	V = A.inv() * b
	return V[3]

def expToLTI(X):
	# print(X)
	X = expand(simplify(X))
	n, d = fraction(X)
	n, d = Poly(n, symbols('s')).all_coeffs(), Poly(d, symbols('s')).all_coeffs()
	n, d = [float(f) for f in n], [float (f) for f in d]
	# print(n, d)
	return sp.lti(n, d)

# 1. Step response of lowpass filter
H = expToLTI(lowpass(1e4, 1e4, 1e-9, 1e-9, 1.586, 1 / symbols('s')))
t, x = sp.impulse(H, T = pp.linspace(0, 1e-3, 10000))
pp.plot(t, x)
pp.show()

# 2. Output of given signal
H = expToLTI(lowpass(1e4, 1e4, 1e-9, 1e-9, 1.586, 1))
v = lambda t : (pp.sin(pp.pi*2e3*t) + pp.cos(pp.pi*2e6*t)) * (t > 0)
t = pp.linspace(0, 1e-3, int(1e5 + 1))
v_t = v(t)
t, x, _ = sp.lsim(H, v_t, t)
pp.plot(t, v_t, label = "original signal")
pp.plot(t, x, label = "signal through filter")
pp.legend()
pp.show()

# 3. Bode Poly of high pass filter
Vo = highpass(1e4, 1e4, 1e-9, 1e-9, 1.586, 1)
ww = pp.logspace(0, 8, 801)
ss = 1j * ww
hf = lambdify(symbols('s'), Vo, "numpy")
v = hf(ss)
pp.loglog(ww, abs(v), lw = 2)
pp.show()

# 4. Response of damped sinusiod
H = expToLTI(highpass(1e4, 1e4, 1e-9, 1e-9, 1.586, 1))

# High frequency
v = lambda t : pp.cos(1e7 * t) * pp.exp(-1e5 * t)
t = pp.linspace(0, 1e-5, int(1e5 + 1))
v_t = v(t)
t, x, _ = sp.lsim(H, v_t, t)
pp.title("high frequency damped sinusoid")
pp.plot(t, v_t, label = "original signal")
pp.plot(t, x, label = "signal through filter")
pp.legend()
pp.show()

# Low frequency
v = lambda t : pp.cos(1e4 * t) * pp.exp(-1e2 * t)
t = pp.linspace(0, 1e-2, int(1e5 + 1))
v_t = v(t)
t, x, _ = sp.lsim(H, v_t, t)
pp.title("low frequency damped sinusoid")
pp.plot(t, v_t, label = "original signal")
pp.plot(t, x, label = "signal through filter")
pp.legend()
pp.show()

# 5. Step response of highpass filter
H = expToLTI(highpass(1e4, 1e4, 1e-9, 1e-9, 1.586, 1 / symbols('s')))
t, x = sp.impulse(H, T = pp.linspace(0, 1e-3, 10000))
pp.plot(t, x)
pp.show()
